﻿Universidad Pontificia Bolivariana

`	`*Data Office Strategy*	

**Sistema de Alerta Temprana para el Desabastecimiento\
de Medicamentos Vitales en Colombia**

Primera Entrega Parcial — Mayo 2026

*Fuente de datos: MEDICAMENTOS VITALES NO DISPONIBLES — datos.gov.co*


**1. Definición del Problema**

En Colombia, los medicamentos vitales no disponibles constituyen una de las alertas más críticas del sistema de salud. Se trata de productos farmacéuticos indispensables e irremplazables para preservar la vida o aliviar el sufrimiento de pacientes, que de forma recurrente no se encuentran disponibles en el territorio nacional o existen en cantidades insuficientes para cubrir la demanda real.

Este fenómeno no es meramente logístico: refleja una falla estructural en la integración de los datos sanitarios con los procesos de planificación, regulación y abastecimiento. El resultado es un sistema que reacciona ante la crisis en lugar de anticiparla.

**1.1 Consecuencias operativas y estratégicas**

- Retrasos en tratamientos prioritarios que comprometen la salud y la vida de los pacientes.
- Incremento en costos operativos por importaciones de emergencia y compras urgentes.
- Sobrecarga administrativa en trámites regulatorios no planificados.
- Riesgo reputacional y legal para las entidades del sistema de salud.
- Baja capacidad de planeación nacional ante variaciones en la demanda.
- Cultura de respuesta reactiva en lugar de gestión preventiva y predictiva.

**2. Necesidad del Negocio desde la Arquitectura Empresarial**

La problemática identificada no puede abordarse exclusivamente desde una perspectiva técnica o logística. Se propone adoptar la Arquitectura Empresarial como marco integrador que permita alinear la estrategia institucional, los procesos operativos, la tecnología y los datos, eliminando los silos de información y habilitando una verdadera transformación digital del sector salud.

Desde esta perspectiva, el problema central no es únicamente la escasez de medicamentos, sino la desarticulación entre tres dimensiones críticas que hoy operan de forma independiente:

|**Procesos Operativos**|**Analítica Predictiva**|**Decisiones Directivas**|
| :-: | :-: | :-: |
|Registro, reporte y seguimiento de alertas sanitarias sin estandarización.|Los datos existen, pero no se utilizan para anticipar riesgos ni proyectar escasez.|Las decisiones regulatorias y de compra se toman sin soporte analítico robusto.|

**3. Estrategia Corporativa Propuesta**

El proyecto propone evolucionar desde el modelo actual —fragmentado y reactivo— hacia una capacidad analítica nacional que permita anticipar riesgos de desabastecimiento de medicamentos críticos y optimizar la toma de decisiones regulatorias, logísticas y clínicas. Este modelo se fundamenta en cuatro pilares estratégicos:

|<p>**Pilares de la Estrategia**</p><p>- Estrategia predictiva y preventiva: anticipar desabastecimientos con base en datos históricos y tendencias.</p><p>- Automatización de procesos: reducir la carga manual en el seguimiento y reporte de alertas sanitarias.</p><p>- Integración y aprovechamiento de datos: consolidar fuentes dispersas en una arquitectura unificada.</p><p>- Toma de decisiones basada en datos: proveer a los tomadores de decisión información oportuna y accionable.</p>|
| :- |

**3.1 Objetivos Estratégicos**

- **Reducción de tiempos de reacción**: disminuir el tiempo de respuesta institucional ante alertas de escasez en al menos un 40 %.
- **Priorización de criticidad**: identificar y clasificar automáticamente los medicamentos con mayor impacto clínico y mayor riesgo de desabastecimiento.
- **Optimización de costos**: reducir los costos asociados a compras urgentes e importaciones de emergencia mediante una planificación anticipada.

**4. Modelado de Procesos — Propuesta Inicial BPM**

A continuación se presenta el diagrama de proceso propuesto en notación BPMN, que modela el flujo desde la detección de una alerta de desabastecimiento hasta la toma de decisión institucional y el cierre del caso. El proceso integra actores del INVIMA, el Ministerio de Salud y las entidades prestadoras de servicios.

![](Aspose.Words.8073ed69-886d-477a-b30a-3fc954c58a61.001.png)

**5. Fuente de Datos Seleccionada**

Para el desarrollo de este proyecto se utilizará el dataset público del Gobierno de Colombia denominado Medicamentos Vitales No Disponibles, disponible a través del portal de Datos Abiertos Colombia. Este conjunto de datos registra todos los eventos de desabastecimiento reportados ante el INVIMA, con atributos que permiten análisis temporales, geográficos y farmacológicos.




|**Fuente**|Datos Abiertos Colombia — datos.gov.co|
| :- | :- |
|**Dataset**|MEDICAMENTOS VITALES NO DISPONIBLES|
|**Identificador**|sdmr-tfmf|
|**Entidad responsable**|INVIMA — Instituto Nacional de Vigilancia de Medicamentos y Alimentos|
|**Tipo de acceso**|Abierto (API REST / CSV descargable)|
|**Variables clave**|Nombre del medicamento, principio activo, laboratorio titular, fecha de reporte, estado del evento, causa del desabastecimiento, vigencia.|

**6. Boceto de Arquitectura de Datos**

A continuación se describe la arquitectura de datos preliminar que se implementará en las fases posteriores del proyecto. La solución sigue un enfoque de capas basado en las mejores prácticas de ingeniería de datos moderna.

|<p>**Capas de la Arquitectura (borrador)**</p><p>- Ingesta: descarga programática del dataset vía API REST de datos.gov.co.</p><p>- Almacenamiento raw: repositorio en formato CSV/Parquet (carpeta /data/raw/ en GitHub).</p><p>- Transformación: pipeline de limpieza y normalización en Python (pandas / Great Expectations).</p><p>- Capa analítica: datos limpios en formato tabular para consumo por notebooks y dashboards.</p><p>- Visualización: dashboard interactivo en Plotly Dash o Power BI para toma de decisiones.</p>|
| :- |

